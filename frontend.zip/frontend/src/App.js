import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import SignUp from './components/auth/SignUp';
import Login from './components/auth/Login';
import OTPVerification from './components/auth/OTPVerification';
import ResetPassword from './components/auth/ResetPassword';
import CreatePost from './components/posts/CreatePost';
import Post from './components/posts/Post';
import Timeline from './components/posts/Timeline';
import Profile from './components/profile/Profile';
import EditProfile from './components/profile/EditProfile';
import Navbar from './components/layout/Navbar';
import Search from './components/layout/Search';
import Notifications from './components/Notifications';
import ForgotPassword from './components/auth/ForgotPassword';

function App() {
  return (
    <Router>
      <Navbar />
      <Search />
      <div className="container">
        <Routes>
          <Route path="/" element={<Timeline />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
          <Route path="/verify-otp" element={<OTPVerification />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/create-post" element={<CreatePost />} />
          <Route path="/post/:id" element={<Post />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/edit-profile" element={<EditProfile />} />
          <Route path="/notifications" element={<Notifications />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
