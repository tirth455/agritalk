import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

export const createPost = (data) => axios.post(`${API_URL}/posts`, data);
export const getPosts = () => axios.get(`${API_URL}/posts`);
export const likePost = (postId) => axios.post(`${API_URL}/posts/${postId}/like`);
export const commentOnPost = (postId, comment) => axios.post(`${API_URL}/posts/${postId}/comments`, { comment });
