import axios from 'axios';

const API_URL = 'http://localhost:5000/api'; // Base URL for your backend API

// Sign up a new user
export const signUp = (data) => axios.post(`${API_URL}/register`, data);

// Log in an existing user
export const login = (data) => axios.post(`${API_URL}/login`, data);

// Verify OTP during sign up or login
export const verifyOTP = (otp) => axios.post(`${API_URL}/verify-otp`, { otp });

// Reset user password
export const resetPassword = (data) => axios.post(`${API_URL}/reset-password`, data);

// Request password reset (forgot password)
export const forgotPassword = (data) => axios.post(`${API_URL}/forgot-password`, data);

// Get the user profile
export const getUserProfile = () => axios.get(`${API_URL}/profile`);

// Edit the user profile
export const editProfile = (data) => axios.put(`${API_URL}/profile`, data);
