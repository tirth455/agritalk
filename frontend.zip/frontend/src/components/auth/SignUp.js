import React, { useState } from 'react';
import { signUp } from '../../api/authApi'; // Adjust the path as necessary

const SignUp = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await signUp({ email, password });
      setMessage('Registration successful! Please check your email to verify your account.');
    } catch (err) {
      setError('Registration failed. Please try again.');
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Register</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="formEmail" className="block text-lg font-medium mb-2">Email</label>
          <input
            type="email"
            id="formEmail"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full border-gray-300 rounded-md shadow-sm p-2"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="formPassword" className="block text-lg font-medium mb-2">Password</label>
          <input
            type="password"
            id="formPassword"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full border-gray-300 rounded-md shadow-sm p-2"
          />
        </div>

        <button type="submit" className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600">
          Register
        </button>
        {error && <div className="mt-3 text-red-500">{error}</div>}
        {message && <div className="mt-3 text-green-500">{message}</div>}
      </form>
    </div>
  );
};

export default SignUp;
