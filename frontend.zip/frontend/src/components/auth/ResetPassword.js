import React, { useState } from 'react';
import { resetPassword } from '../../api/authApi'; // Adjust the path as necessary

const ResetPassword = () => {
  const [token, setToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState(null);
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await resetPassword({ token, newPassword });
      setMessage('Password has been reset successfully!');
    } catch (err) {
      setError('Failed to reset password. Please try again.');
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Reset Password</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="formToken" className="block text-lg font-medium mb-2">Reset Token</label>
          <input
            type="text"
            id="formToken"
            placeholder="Enter the reset token"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            required
            className="w-full border-gray-300 rounded-md shadow-sm p-2"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="formNewPassword" className="block text-lg font-medium mb-2">New Password</label>
          <input
            type="password"
            id="formNewPassword"
            placeholder="Enter your new password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            required
            className="w-full border-gray-300 rounded-md shadow-sm p-2"
          />
        </div>

        <button type="submit" className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600">
          Reset Password
        </button>
        {error && <div className="mt-3 text-red-500">{error}</div>}
        {message && <div className="mt-3 text-green-500">{message}</div>}
      </form>
    </div>
  );
};

export default ResetPassword;
