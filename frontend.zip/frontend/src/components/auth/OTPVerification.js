import React, { useState } from 'react';
import { verifyOTP } from '../../api/authApi'; // Adjust the path as necessary

const OTPVerification = () => {
  const [otp, setOtp] = useState('');
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await verifyOTP(otp);
      setSuccess('OTP verified successfully!');
      // Redirect or handle successful OTP verification
    } catch (err) {
      setError('Failed to verify OTP. Please try again.');
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Verify OTP</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="formOTP" className="block text-lg font-medium mb-2">OTP</label>
          <input
            type="text"
            id="formOTP"
            placeholder="Enter the OTP"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            required
            className="w-full border-gray-300 rounded-md shadow-sm p-2"
          />
        </div>

        <button type="submit" className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600">
          Verify OTP
        </button>
        {error && <div className="mt-3 text-red-500">{error}</div>}
        {success && <div className="mt-3 text-green-500">{success}</div>}
      </form>
    </div>
  );
};

export default OTPVerification;
