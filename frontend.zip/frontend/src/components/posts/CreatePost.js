import React, { useState } from 'react';
import { createPost } from '../../api/postApi';

const CreatePost = () => {
  const [text, setText] = useState('');
  const [media, setMedia] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleFileChange = (e) => {
    setMedia(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('text', text);
    if (media) formData.append('media', media);

    try {
      await createPost(formData);
      setSuccess('Post created successfully!');
      setText('');
      setMedia(null);
    } catch (err) {
      setError('Failed to create post. Please try again.');
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4 bg-white shadow-md rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Create Post</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex flex-col">
          <label htmlFor="text" className="mb-2 text-sm font-semibold text-gray-700">Text</label>
          <textarea
            id="text"
            placeholder="What's on your mind?"
            value={text}
            onChange={(e) => setText(e.target.value)}
            required
            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex flex-col">
          <label htmlFor="media" className="mb-2 text-sm font-semibold text-gray-700">Upload Media</label>
          <input
            type="file"
            id="media"
            onChange={handleFileChange}
            className="file:border file:py-2 file:px-4 file:bg-blue-500 file:text-white file:rounded-md file:cursor-pointer hover:file:bg-blue-600"
          />
        </div>

        <button
          type="submit"
          className="w-full py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Post
        </button>

        {error && <div className="mt-4 p-2 bg-red-100 text-red-700 border border-red-300 rounded-md">{error}</div>}
        {success && <div className="mt-4 p-2 bg-green-100 text-green-700 border border-green-300 rounded-md">{success}</div>}
      </form>
    </div>
  );
};

export default CreatePost;
