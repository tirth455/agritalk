import React, { useEffect, useState } from 'react';
import { getPosts } from '../../api/postApi';
import Post from './Post';

const Timeline = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchPosts = async () => {
      const data = await getPosts();
      setPosts(data);
    };
    fetchPosts();
  }, []);

  const handleLike = (postId) => {
    setPosts(posts.map(post =>
      post._id === postId ? { ...post, likes: post.likes + 1 } : post
    ));
  };

  const handleComment = (postId) => {
    // Handle comment logic
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h2 className="text-2xl font-bold mb-6">Timeline</h2>
      {posts.length > 0 ? (
        posts.map(post => (
          <Post key={post._id} post={post} onLike={handleLike} onComment={handleComment} />
        ))
      ) : (
        <p className="text-gray-500">No posts available</p>
      )}
    </div>
  );
};

export default Timeline;
