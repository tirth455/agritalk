import React from 'react';
import { Button, Card } from 'react-bootstrap';
import { likePost } from '../../api/postApi';

const Post = ({ post, onLike, onComment }) => {
  const handleLike = async () => {
    await likePost(post._id);
    onLike(post._id);
  };

  return (
    <div className="max-w-xl mx-auto bg-white shadow-md rounded-lg mb-4">
      <div className="p-4">
        <p className="text-gray-800 mb-2">{post.text}</p>
        {post.media && (
          <img
            src={post.mediaUrl}
            alt="Post media"
            className="w-full h-auto rounded-md mb-2"
          />
        )}
        <div className="flex items-center space-x-4">
          <button
            onClick={handleLike}
            className="text-blue-500 hover:text-blue-700 focus:outline-none"
          >
            Like ({post.likes.length})
          </button>
          <button
            onClick={() => onComment(post._id)}
            className="text-blue-500 hover:text-blue-700 focus:outline-none"
          >
            Comment
          </button>
        </div>
      </div>
    </div>
  );
};

export default Post;
