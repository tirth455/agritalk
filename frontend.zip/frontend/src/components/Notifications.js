import React from 'react';

const Notifications = () => {
  // Mock notifications
  const notifications = [
    'User A liked your post.',
    'User B commented on your post.',
  ];

  return (
    <div className="max-w-lg mx-auto p-6 bg-white shadow-md rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Notifications</h2>
      <ul className="list-disc pl-5">
        {notifications.map((notification, index) => (
          <li key={index} className="text-lg text-gray-700 mb-2">
            {notification}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Notifications;
