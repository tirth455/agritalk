import React, { useEffect, useState } from 'react';
import { getUserProfile } from '../../api/authApi';

const Profile = () => {
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      const data = await getUserProfile();
      setProfile(data);
    };
    fetchProfile();
  }, []);

  if (!profile) return <div className="text-center text-lg">Loading...</div>;

  return (
    <div className="max-w-md mx-auto p-6">
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-3xl font-bold mb-4">{profile.name}</h2>
        <p className="text-lg text-gray-700 mb-2">{profile.email}</p>
        <p className="text-gray-600">{profile.bio}</p>
      </div>
    </div>
  );
};

export default Profile;
