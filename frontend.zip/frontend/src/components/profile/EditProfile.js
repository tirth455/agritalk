import React, { useState, useEffect } from 'react';
import { editProfile, getUserProfile } from '../../api/authApi';
import { Button, Form, Alert } from 'react-bootstrap';

const EditProfile = () => {
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await getUserProfile();
        const profile = response.data; // Adjust based on API response structure
        setName(profile.name);
        setBio(profile.bio);
      } catch (err) {
        setError('Failed to fetch profile. Please try again.');
      }
    };
    fetchProfile();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await editProfile({ name, bio });
      setSuccess('Profile updated successfully!');
    } catch (err) {
      setError('Failed to update profile. Please try again.');
    }
  };

  return (
    <div className="max-w-md mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Edit Profile</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="formName">
          <Form.Label className="block text-gray-700 text-sm font-bold mb-2">Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border border-gray-300 rounded-md shadow-sm p-2 w-full"
            required
          />
        </Form.Group>

        <Form.Group controlId="formBio" className="mt-4">
          <Form.Label className="block text-gray-700 text-sm font-bold mb-2">Bio</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            placeholder="Bio"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            className="border border-gray-300 rounded-md shadow-sm p-2 w-full"
          />
        </Form.Group>

        <Button variant="primary" type="submit" className="mt-4">
          Save Changes
        </Button>

        {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
        {success && <Alert variant="success" className="mt-3">{success}</Alert>}
      </Form>
    </div>
  );
};

export default EditProfile;
