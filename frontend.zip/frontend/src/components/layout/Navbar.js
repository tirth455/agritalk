import React from 'react';
import { Link } from 'react-router-dom';

const NavBar = () => {
  return (
    <nav className="bg-blue-500 p-4 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-white text-xl font-bold">
          AgriTalk
        </Link>
        <div className="flex space-x-4">
          <Link to="/timeline" className="text-white hover:text-gray-300">
            Timeline
          </Link>
          <Link to="/profile" className="text-white hover:text-gray-300">
            Profile
          </Link>
        </div>
        <div className="flex space-x-4">
          <Link to="/login" className="text-white hover:text-gray-300">
            Login
          </Link>
          <Link to="/signup" className="text-white hover:text-gray-300">
            Sign Up
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
